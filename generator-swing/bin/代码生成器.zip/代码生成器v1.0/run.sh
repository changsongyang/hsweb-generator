#!/bin/sh
java -cp generator-swing.jar org.hsweb.generator.swing.SwingGeneratorApplication

